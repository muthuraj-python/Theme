$(function() {

  $(".knob").knob({
    thickness: '.05',
    font: "Open Sans",
    bgColor: "#f3eee7",
    readOnly: true
  });

});